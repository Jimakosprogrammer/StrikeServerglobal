# Strike Server v2
Supports register/login/sync/leaderboard + password reset.
